package custom.genBarCode;

import org.apache.commons.mail.*;
import com.keepautomation.barcode.BarCode;
import com.keepautomation.barcode.IBarCode;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.mail.util.ByteArrayDataSource;


public class genBarCode {
    
    
    private static BufferedImage bfImage = new BufferedImage(500, 500, BufferedImage.TYPE_INT_RGB);
    private static BarCode code128 = new BarCode();
    public static void encodeImage(String barCode, String emailTo, String fName, 
    								String ref,String smtpHost, String emailFrom,String emailSub)
   {
        byte[] imgBytes = new byte[15*1024];
        try 
        {        	
            ByteArrayOutputStream imgStream = generateBarCode(barCode);
            InputStream is = new ByteArrayInputStream(imgStream.toByteArray());
            int bytesRead = 0;
            while ((bytesRead = is.read(imgBytes)) != -1) {
                imgStream.write(imgBytes, 0, bytesRead);
            }
            sendEmail(barCode,imgStream.toByteArray(),emailTo,fName,ref,smtpHost,emailFrom,emailSub);
        } catch (Exception e) {
            e.printStackTrace();  
        }
    }
    
    public static ByteArrayOutputStream generateBarCode(String barCode)
    {
    	ByteArrayOutputStream baos = new ByteArrayOutputStream();
    	
    	try 
    	{
    		code128.setCodeToEncode(barCode);
     	   	code128.setSymbology(IBarCode.CODE128);
     	    code128.setX(2);
     	    code128.setY(50);
     	    code128.setRightMargin(0);
     	    code128.setLeftMargin(0);
            code128.setTopMargin(0);
            code128.setBottomMargin(0);
            code128.setChecksumEnabled(false);
            code128.setFnc1(IBarCode.FNC1_NONE);
            bfImage = code128.draw();
            ImageIO.write(bfImage, "png", baos);
    		
    	} catch (Exception e) {
       	  	e.printStackTrace();
       	}
    	
    	return baos;
    	
    }
    
    public static void sendEmail(String barCode,byte[] encodedVar,String emailTo, String fName, 
    							String ref,String smtpHost, String emailFrom,String emailSub)
    {
        try 
        {
            HtmlEmail email = new HtmlEmail();
            
            email.setHostName(smtpHost);
            email.setFrom(emailFrom);
            email.setSubject(emailSub);
            email.addTo(emailTo);
            email.addTo("tamoghna_ghatak@yahoo.com");
            email.addTo("bitan.ghatak@gmail.com");
            //email.addTo("JT.Benjaminsen@coastcapitalsavings.com");
            //email.addTo("Ethan.Verma@coastcapitalsavings.com");
            //email.addTo("j.t.benjaminsen@gmail.com");
          /*  String[] emailArr = emailList.split(",");
            for (String s: emailArr) {           
                email.addTo(s);
            }  */
            
            ImageHtmlEmail emailImg = new ImageHtmlEmail();
           	ByteArrayDataSource imageDataSource = new ByteArrayDataSource(encodedVar, "image/png");
           	String contentId = emailImg.embed(imageDataSource, "Bar Code");
            StringBuffer msgbody = new StringBuffer();
            msgbody.append("<html><body>");
            msgbody.append(addHeader());
            msgbody.append("<p>Dear  ").append(fName).append(" ,</p>");
            msgbody.append("<p>In order for us to ensure we have the right person, you will need to go to your nearest Canada Post location and show valid ID.\r\n" + 
            		"Once you have made your way to the Canada Post location nearest you, show the barcode below along with your valid ID. If everything checks out, we will send you an approval notification within 2 business days, but most likely sooner.</p>");
            msgbody.append("<p><img src=cid:").append(email.embed(imageDataSource, contentId)).append("></p>");
            msgbody.append("<p>Bar Code Number : ").append(barCode).append("</p>");
            msgbody.append("<p>Your reference number is ").append(ref).append(". Thank you for taking the time to submit your membership application.</p>");
            msgbody.append("<p>Happy to help,");
            msgbody.append("<br/>");
            msgbody.append("Coast Capital Savings</p>");
            msgbody.append(addFooter());
            msgbody.append("</body></html>");
            email.setHtmlMsg(msgbody.toString());
            email.send();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static String addHeader()
    {
    	String msgHeader = "<tr>\r\n" + 
    			"    <td colspan=\"4\" align=\"left\" valign=\"top\">\r\n" + 
    			"        <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"background-color:#0067c6;\">\r\n" + 
    			"            <tr>\r\n" + 
    			"                <td colspan=\"3\" align=\"left\" valign=\"top\"><img src=\"https://coastcapitalsavings.com/SharedContent/images/Email/header-blue1.jpg\" width=\"620\" height=\"13\" /></td>\r\n" + 
    			"            </tr>\r\n" + 
    			"            <tr>\r\n" + 
    			"                <td width=\"252\" align=\"left\" valign=\"top\">\r\n" + 
    			"				<a href=\"https://www.coastcapitalsavings.com?utm_source=dmo&utm_medium=email&utm_campaign=dmobasic&utm_content=header\">\r\n" + 
    			"				<img src=\"https://coastcapitalsavings.com/SharedContent/images/Email/header-blue2.jpg\" alt=\"Coast Capital Savings\" width=\"252\" height=\"68\" border=\"0\" /></a></td>\r\n" + 
    			"                <td width=\"302\" align=\"left\" valign=\"top\"><img src=\"https://coastcapitalsavings.com/SharedContent/images/Email/header-blue3.jpg\" width=\"302\" height=\"68\" /></td>\r\n" + 
    			"            </tr>\r\n" + 
    			"        </table>\r\n" + 
    			"    </td>\r\n" + 
    			"</tr>";
    	
    	return msgHeader;
    }
    
    public static String addFooter()
    {
    	String msgFooter = "<tr>\r\n" + 
    			"    <td colspan=\"4\" align=\"left\" valign=\"top\">\r\n" + 
    			"        <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"background-color:#0067c6;\">\r\n" + 
    			"            <tr>\r\n" + 
    			"                <td colspan=\"3\" align=\"left\" valign=\"top\"><img src=\"https://coastcapitalsavings.com/SharedContent/images/Email/header-blue1.jpg\" width=\"620\" height=\"13\" /></td>\r\n" + 
    			"            </tr>\r\n" + 
    			"            <tr>\r\n" + 
    			"                <td width=\"252\" align=\"left\" valign=\"top\">\r\n" + 
    			"				<a href=\"https://www.coastcapitalsavings.com?utm_source=dmo&utm_medium=email&utm_campaign=dmobasic&utm_content=header\">\r\n" + 
    			"				<img src=\"https://coastcapitalsavings.com/SharedContent/images/Email/header-blue2.jpg\" alt=\"Coast Capital Savings\" width=\"252\" height=\"68\" border=\"0\" /></a></td>\r\n" + 
    			"                <td width=\"302\" align=\"left\" valign=\"top\"><img src=\"https://coastcapitalsavings.com/SharedContent/images/Email/header-blue3.jpg\" width=\"302\" height=\"68\" /></td>\r\n" + 
    			"            </tr>\r\n" + 
    			"        </table>\r\n" + 
    			"    </td>\r\n" + 
    			"</tr>";
    	
    	return msgFooter;
    }
    
}

