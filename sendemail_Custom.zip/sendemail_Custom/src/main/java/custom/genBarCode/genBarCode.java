package custom.genBarCode;

import org.apache.commons.mail.*;
import com.keepautomation.barcode.BarCode;
import com.keepautomation.barcode.IBarCode;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.mail.util.ByteArrayDataSource;


public class genBarCode {
    
    
    private static BufferedImage bfImage = new BufferedImage(500, 500, BufferedImage.TYPE_INT_RGB);
    private static BarCode code128 = new BarCode();
    public static void encodeImage(String str)
   {
        byte[] imgBytes = new byte[15*1024];
        try 
        {
                    	
            ByteArrayOutputStream imgStream = generateBarCode(str);
            InputStream is = new ByteArrayInputStream(imgStream.toByteArray());
            int bytesRead = 0;
            while ((bytesRead = is.read(imgBytes)) != -1) {
                imgStream.write(imgBytes, 0, bytesRead);
            }
            sendEmail(imgStream.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();  
        }
    }
    
    public static ByteArrayOutputStream generateBarCode(String str)
    {
    	ByteArrayOutputStream baos = new ByteArrayOutputStream();
    	
    	try 
    	{
    		code128.setCodeToEncode(str);
     	   	code128.setSymbology(IBarCode.CODE128);
     	    code128.setX(2);
     	    code128.setY(50);
     	    code128.setRightMargin(0);
     	    code128.setLeftMargin(0);
            code128.setTopMargin(0);
            code128.setBottomMargin(0);
            code128.setChecksumEnabled(false);
            code128.setFnc1(IBarCode.FNC1_NONE);
            bfImage = code128.draw();
            ImageIO.write(bfImage, "png", baos);
    		
    	} catch (Exception e) {
       	  	e.printStackTrace();
       	}
    	
    	return baos;
    	
    }
    
    public static void sendEmail(byte[] encodedVar)
    {
        try 
        {
            String smtpServer = "smtpforwarder.coastcapital.local";
            HtmlEmail email = new HtmlEmail();
            
            email.setHostName(smtpServer);
            email.setFrom("tamoghna.ghatak@coastcapitalsavings.com");
            email.setSubject("Your Canada Post BarCode");
            
           /* for (String s: arr) {           
                email.addTo(s);
            } */
            
            email.addTo("bitan.ghatak@gmail.com");
            //email.addTo("bitan.ghatak@gmail.com");
            /*email.addTo("Alan.Wu@coastcapitalsavings.com");
            email.addTo("Owais.Siddiqui@coastcapitalsavings.com");
            email.addTo("Ethan.Verma@coastcapitalsavings.com");
            email.addTo("Piotr.Tymkow@coastcapitalsavings.com");*/
            
            ImageHtmlEmail emailImg = new ImageHtmlEmail();
           	ByteArrayDataSource imageDataSource = new ByteArrayDataSource(encodedVar, "image/png");
           	String contentId = emailImg.embed(imageDataSource, "Bar Code");
            StringBuffer msg = new StringBuffer();
            msg.append("<html><body>");
            msg.append("<h1>Canada Post BarCode</h1>");
            msg.append("<img src=cid:").append(email.embed(imageDataSource, contentId)).append(">");
            msg.append("</body></html>");
            email.setHtmlMsg(msg.toString());
            email.send();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}

